import type { Express, Request, Response } from "express";
import { createServer, type Server } from "node:http";
import YahooFinance from "yahoo-finance2";

const yahooFinance = new YahooFinance();

function calculateSMA(prices: number[], period: number): number[] {
  const sma: number[] = [];
  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      sma.push(0);
    } else {
      const slice = prices.slice(i - period + 1, i + 1);
      sma.push(slice.reduce((a, b) => a + b, 0) / period);
    }
  }
  return sma;
}

function calculateEMA(prices: number[], period: number): number[] {
  const ema: number[] = [];
  const multiplier = 2 / (period + 1);
  ema.push(prices[0]);
  for (let i = 1; i < prices.length; i++) {
    ema.push((prices[i] - ema[i - 1]) * multiplier + ema[i - 1]);
  }
  return ema;
}

function calculateRSI(prices: number[], period: number = 14): number[] {
  const rsi: number[] = [];
  const changes: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    changes.push(prices[i] - prices[i - 1]);
  }
  for (let i = 0; i < changes.length; i++) {
    if (i < period) {
      rsi.push(50);
      continue;
    }
    const slice = changes.slice(i - period, i);
    const gains = slice.filter((c) => c > 0).reduce((a, b) => a + b, 0) / period;
    const losses = Math.abs(slice.filter((c) => c < 0).reduce((a, b) => a + b, 0)) / period;
    if (losses === 0) {
      rsi.push(100);
    } else {
      const rs = gains / losses;
      rsi.push(100 - 100 / (1 + rs));
    }
  }
  return rsi;
}

function calculateMACD(prices: number[]): { macd: number[]; signal: number[]; histogram: number[] } {
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);
  const macdLine = ema12.map((v, i) => v - ema26[i]);
  const signalLine = calculateEMA(macdLine, 9);
  const histogram = macdLine.map((v, i) => v - signalLine[i]);
  return { macd: macdLine, signal: signalLine, histogram };
}

function linearRegression(data: number[]): { slope: number; intercept: number; r2: number } {
  const n = data.length;
  const x = data.map((_, i) => i);
  const sumX = x.reduce((a, b) => a + b, 0);
  const sumY = data.reduce((a, b) => a + b, 0);
  const sumXY = x.reduce((a, xi, i) => a + xi * data[i], 0);
  const sumXX = x.reduce((a, xi) => a + xi * xi, 0);
  const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;
  const yMean = sumY / n;
  const ssRes = data.reduce((a, yi, i) => a + (yi - (slope * i + intercept)) ** 2, 0);
  const ssTot = data.reduce((a, yi) => a + (yi - yMean) ** 2, 0);
  const r2 = ssTot === 0 ? 0 : 1 - ssRes / ssTot;
  return { slope, intercept, r2 };
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/stock/:symbol", async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const quote = await yahooFinance.quote(symbol.toUpperCase());
      if (!quote) {
        return res.status(404).json({ error: "Stock not found" });
      }
      res.json({
        symbol: quote.symbol,
        name: quote.shortName || quote.longName || quote.symbol,
        price: quote.regularMarketPrice || 0,
        change: quote.regularMarketChange || 0,
        changePercent: quote.regularMarketChangePercent || 0,
        previousClose: quote.regularMarketPreviousClose || 0,
        open: quote.regularMarketOpen || 0,
        dayHigh: quote.regularMarketDayHigh || 0,
        dayLow: quote.regularMarketDayLow || 0,
        volume: quote.regularMarketVolume || 0,
        marketCap: quote.marketCap || 0,
        fiftyTwoWeekHigh: quote.fiftyTwoWeekHigh || 0,
        fiftyTwoWeekLow: quote.fiftyTwoWeekLow || 0,
        exchange: quote.exchange || "",
      });
    } catch (error: any) {
      console.error("Stock fetch error:", error.message);
      res.status(500).json({ error: "Failed to fetch stock data" });
    }
  });

  app.get("/api/stock/:symbol/history", async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const range = (req.query.range as string) || "1mo";
      const intervalMap: Record<string, string> = {
        "1d": "5m",
        "5d": "15m",
        "1mo": "1d",
        "3mo": "1d",
        "6mo": "1d",
        "1y": "1wk",
        "5y": "1mo",
      };
      const interval = intervalMap[range] || "1d";
      const result = await yahooFinance.chart(symbol.toUpperCase(), {
        period1: getStartDate(range),
        interval: interval as any,
      });
      const quotes = result.quotes || [];
      const prices = quotes
        .filter((q: any) => q.close != null)
        .map((q: any) => ({
          date: new Date(q.date).toISOString(),
          open: q.open || 0,
          high: q.high || 0,
          low: q.low || 0,
          close: q.close || 0,
          volume: q.volume || 0,
        }));
      const closePrices = prices.map((p: any) => p.close);
      const sma20 = calculateSMA(closePrices, Math.min(20, closePrices.length));
      const ema12 = calculateEMA(closePrices, Math.min(12, closePrices.length));
      const rsi = calculateRSI(closePrices);
      const macd = calculateMACD(closePrices);
      res.json({
        symbol: symbol.toUpperCase(),
        range,
        prices,
        indicators: {
          sma20: sma20.slice(-1)[0] || 0,
          ema12: ema12.slice(-1)[0] || 0,
          rsi: rsi.slice(-1)[0] || 50,
          macd: {
            value: macd.macd.slice(-1)[0] || 0,
            signal: macd.signal.slice(-1)[0] || 0,
            histogram: macd.histogram.slice(-1)[0] || 0,
          },
        },
      });
    } catch (error: any) {
      console.error("History fetch error:", error.message);
      res.status(500).json({ error: "Failed to fetch history" });
    }
  });

  app.get("/api/stock/:symbol/search", async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const results = await yahooFinance.search(symbol);
      const stocks = (results.quotes || [])
        .filter((q: any) => q.quoteType === "EQUITY")
        .slice(0, 8)
        .map((q: any) => ({
          symbol: q.symbol,
          name: q.shortname || q.longname || q.symbol,
          exchange: q.exchange || "",
        }));
      res.json(stocks);
    } catch (error: any) {
      console.error("Search error:", error.message);
      res.status(500).json({ error: "Search failed" });
    }
  });

  app.get("/api/predict/:symbol", async (req: Request, res: Response) => {
    try {
      const { symbol } = req.params;
      const result = await yahooFinance.chart(symbol.toUpperCase(), {
        period1: getStartDate("3mo"),
        interval: "1d",
      });
      const quotes = result.quotes || [];
      const closePrices = quotes.filter((q: any) => q.close != null).map((q: any) => q.close);
      if (closePrices.length < 10) {
        return res.status(400).json({ error: "Not enough data for prediction" });
      }
      const { slope, intercept, r2 } = linearRegression(closePrices);
      const predictedPrice = slope * closePrices.length + intercept;
      const currentPrice = closePrices[closePrices.length - 1];
      const priceChange = predictedPrice - currentPrice;
      const percentChange = (priceChange / currentPrice) * 100;
      const rsi = calculateRSI(closePrices);
      const currentRSI = rsi[rsi.length - 1] || 50;
      const sma20 = calculateSMA(closePrices, 20);
      const currentSMA = sma20[sma20.length - 1];
      let trend: string;
      let signal: string;
      if (slope > 0 && currentRSI < 70) {
        trend = "Bullish";
        signal = currentRSI < 30 ? "Strong Buy" : "Buy";
      } else if (slope < 0 && currentRSI > 30) {
        trend = "Bearish";
        signal = currentRSI > 70 ? "Strong Sell" : "Sell";
      } else {
        trend = "Neutral";
        signal = "Hold";
      }
      const confidence = Math.min(95, Math.max(25, Math.round(Math.abs(r2) * 100)));
      res.json({
        symbol: symbol.toUpperCase(),
        currentPrice,
        predictedPrice: Math.round(predictedPrice * 100) / 100,
        priceChange: Math.round(priceChange * 100) / 100,
        percentChange: Math.round(percentChange * 100) / 100,
        trend,
        signal,
        confidence,
        rsi: Math.round(currentRSI * 100) / 100,
        sma20: currentSMA ? Math.round(currentSMA * 100) / 100 : null,
        disclaimer: "This is not financial advice. Predictions are based on historical data analysis and may not reflect future performance.",
      });
    } catch (error: any) {
      console.error("Prediction error:", error.message);
      res.status(500).json({ error: "Prediction failed" });
    }
  });

  app.post("/api/chat", async (req: Request, res: Response) => {
    try {
      const { message } = req.body;
      if (!message) {
        return res.status(400).json({ error: "Message required" });
      }
      const lower = message.toLowerCase();
      let reply = "";
      const tickerMatch = lower.match(/\b([a-z]{1,5})\b/gi);
      const stockSymbols = tickerMatch
        ? tickerMatch.filter((t: string) =>
            ["aapl", "googl", "goog", "msft", "amzn", "tsla", "meta", "nvda", "nflx", "spy", "qqq", "amd", "intc", "dis", "ba", "v", "jpm", "wmt", "ko", "pep"].includes(t.toLowerCase())
          )
        : [];
      if (lower.includes("buy") || lower.includes("should i invest") || lower.includes("good time")) {
        reply = "Before making any investment decision, consider these factors:\n\n1. Check the RSI - below 30 may indicate oversold conditions\n2. Look at the trend direction using SMA/EMA\n3. Review the company's fundamentals\n4. Consider your risk tolerance and investment horizon\n5. Diversify your portfolio\n\nRemember: Past performance doesn't guarantee future results. Always do your own research.";
      } else if (lower.includes("sell") || lower.includes("exit")) {
        reply = "Consider selling when:\n\n1. RSI is above 70 (overbought)\n2. Price breaks below key moving averages\n3. Your target profit has been reached\n4. The fundamental thesis has changed\n5. You need to rebalance your portfolio\n\nAlways set stop-losses to manage risk.";
      } else if (lower.includes("rsi") || lower.includes("indicator")) {
        reply = "Key Technical Indicators:\n\nRSI (Relative Strength Index): Measures momentum. Below 30 = oversold, above 70 = overbought.\n\nSMA (Simple Moving Average): Smooths price data. Price above SMA = bullish trend.\n\nEMA (Exponential Moving Average): Like SMA but weights recent prices more heavily.\n\nMACD: Shows trend direction and momentum. Bullish when MACD crosses above signal line.";
      } else if (lower.includes("portfolio") || lower.includes("diversif")) {
        reply = "Portfolio Best Practices:\n\n1. Diversify across sectors (tech, healthcare, finance, etc.)\n2. Mix growth and value stocks\n3. Consider index funds for broad exposure\n4. Rebalance quarterly\n5. Keep cash reserves for opportunities\n6. Don't put more than 5-10% in any single stock";
      } else if (lower.includes("risk") || lower.includes("safe")) {
        reply = "Risk Management Tips:\n\n1. Never invest money you can't afford to lose\n2. Use stop-loss orders (typically 5-10% below entry)\n3. Position sizing - risk only 1-2% per trade\n4. Dollar-cost averaging reduces timing risk\n5. Higher returns = higher risk\n6. Government bonds and blue chips are generally lower risk";
      } else if (stockSymbols.length > 0) {
        const sym = stockSymbols[0].toUpperCase();
        reply = `To analyze ${sym}, I'd recommend:\n\n1. Check the stock detail page for current price and technicals\n2. Use the AI Prediction feature for trend analysis\n3. Review the RSI for overbought/oversold signals\n4. Compare against sector performance\n\nUse the search function to look up ${sym} for detailed data.`;
      } else if (lower.includes("hello") || lower.includes("hi") || lower.includes("hey")) {
        reply = "Hello! I'm your StockAI trading assistant. I can help with:\n\n- Buy/Sell guidance based on technical indicators\n- RSI, SMA, EMA, MACD explanations\n- Portfolio diversification tips\n- Risk management strategies\n\nWhat would you like to know?";
      } else {
        reply = "I can help you with stock trading insights. Try asking about:\n\n- When to buy or sell a stock\n- Technical indicators (RSI, SMA, EMA, MACD)\n- Portfolio diversification\n- Risk management\n- Specific stock analysis (mention a ticker like AAPL)\n\nWhat would you like to explore?";
      }
      res.json({
        reply,
        disclaimer: "This is AI-generated guidance, not financial advice. Always consult a financial advisor.",
      });
    } catch (error: any) {
      console.error("Chat error:", error.message);
      res.status(500).json({ error: "Chat failed" });
    }
  });

  app.get("/api/trending", async (_req: Request, res: Response) => {
    try {
      const symbols = ["AAPL", "GOOGL", "MSFT", "AMZN", "TSLA", "NVDA", "META", "NFLX"];
      const quotes = await Promise.all(
        symbols.map(async (symbol) => {
          try {
            const quote = await yahooFinance.quote(symbol);
            return {
              symbol: quote.symbol,
              name: quote.shortName || quote.longName || symbol,
              price: quote.regularMarketPrice || 0,
              change: quote.regularMarketChange || 0,
              changePercent: quote.regularMarketChangePercent || 0,
              volume: quote.regularMarketVolume || 0,
            };
          } catch {
            return null;
          }
        })
      );
      res.json(quotes.filter(Boolean));
    } catch (error: any) {
      console.error("Trending error:", error.message);
      res.status(500).json({ error: "Failed to fetch trending" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function getStartDate(range: string): string {
  const now = new Date();
  switch (range) {
    case "1d":
      now.setDate(now.getDate() - 1);
      break;
    case "5d":
      now.setDate(now.getDate() - 5);
      break;
    case "1mo":
      now.setMonth(now.getMonth() - 1);
      break;
    case "3mo":
      now.setMonth(now.getMonth() - 3);
      break;
    case "6mo":
      now.setMonth(now.getMonth() - 6);
      break;
    case "1y":
      now.setFullYear(now.getFullYear() - 1);
      break;
    case "5y":
      now.setFullYear(now.getFullYear() - 5);
      break;
    default:
      now.setMonth(now.getMonth() - 1);
  }
  return now.toISOString().split("T")[0];
}
