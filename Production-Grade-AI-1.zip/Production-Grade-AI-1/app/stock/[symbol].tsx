import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Alert,
  Platform,
  TextInput,
  Modal,
} from "react-native";
import { useLocalSearchParams, Stack } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { StockChart } from "@/components/StockChart";
import { formatPrice, formatChange, formatPercent, formatVolume, formatMarketCap } from "@/lib/format";
import { usePortfolio } from "@/lib/portfolio-context";
import { getApiUrl } from "@/lib/query-client";
import { fetch } from "expo/fetch";

const RANGES = ["1d", "5d", "1mo", "3mo", "6mo", "1y"];

export default function StockDetailScreen() {
  const { symbol } = useLocalSearchParams<{ symbol: string }>();
  const { addHolding, removeHolding, holdings } = usePortfolio();
  const [selectedRange, setSelectedRange] = useState("1mo");
  const [showAddModal, setShowAddModal] = useState(false);
  const [addShares, setAddShares] = useState("");
  const [addLoading, setAddLoading] = useState(false);

  const isInPortfolio = holdings.some((h) => h.symbol === symbol);

  const { data: quote, isLoading: quoteLoading } = useQuery<any>({
    queryKey: [`/api/stock/${symbol}`],
    staleTime: 30000,
  });

  const { data: history, isLoading: historyLoading } = useQuery<any>({
    queryKey: [`/api/stock/${symbol}/history`, `?range=${selectedRange}`],
    queryFn: async () => {
      const baseUrl = getApiUrl();
      const url = new URL(`/api/stock/${symbol}/history?range=${selectedRange}`, baseUrl);
      const res = await fetch(url.toString());
      if (!res.ok) throw new Error("Failed to fetch history");
      return res.json();
    },
    staleTime: 60000,
  });

  const handleAddToPortfolio = useCallback(async () => {
    if (!addShares || !quote) return;
    setAddLoading(true);
    try {
      await addHolding({
        symbol: symbol!,
        name: quote.name,
        shares: parseFloat(addShares),
        avgPrice: quote.price,
      });
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      setShowAddModal(false);
      setAddShares("");
    } catch {
      Alert.alert("Error", "Failed to add stock");
    } finally {
      setAddLoading(false);
    }
  }, [addShares, quote, symbol, addHolding]);

  if (quoteLoading) {
    return (
      <View style={styles.loadingContainer}>
        <Stack.Screen options={{ title: symbol || "" }} />
        <ActivityIndicator color={Colors.dark.accent} size="large" />
      </View>
    );
  }

  if (!quote) {
    return (
      <View style={styles.loadingContainer}>
        <Stack.Screen options={{ title: symbol || "" }} />
        <View style={styles.errorIcon}>
          <Ionicons name="alert-circle" size={48} color={Colors.dark.negative} />
        </View>
        <Text style={styles.errorTitle}>Stock not found</Text>
        <Text style={styles.errorSubtext}>
          "{symbol}" doesn't appear to be a valid stock symbol.{"\n"}
          {symbol === "AALP" ? 'Did you mean "AAPL" (Apple Inc.)?' : "Please check the symbol and try again."}
        </Text>
        {isInPortfolio && (
          <Pressable
            style={({ pressed }) => [styles.removeButton, pressed && { opacity: 0.8 }]}
            onPress={() => {
              Alert.alert("Remove from Portfolio", `Remove ${symbol} from your portfolio?`, [
                { text: "Cancel", style: "cancel" },
                {
                  text: "Remove",
                  style: "destructive",
                  onPress: () => {
                    removeHolding(symbol!);
                    if (Platform.OS !== "web") {
                      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
                    }
                    router.back();
                  },
                },
              ]);
            }}
          >
            <Ionicons name="trash-outline" size={18} color={Colors.dark.negative} />
            <Text style={styles.removeButtonText}>Remove from Portfolio</Text>
          </Pressable>
        )}
        <Pressable
          style={({ pressed }) => [styles.goBackButton, pressed && { opacity: 0.8 }]}
          onPress={() => router.back()}
        >
          <Ionicons name="arrow-back" size={18} color={Colors.dark.accent} />
          <Text style={styles.goBackText}>Go Back</Text>
        </Pressable>
      </View>
    );
  }

  const isPositive = quote.change >= 0;

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: quote.name || symbol || "" }} />
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.priceSection}>
          <Text style={styles.symbolText}>{quote.symbol}</Text>
          <Text style={styles.priceText}>${formatPrice(quote.price)}</Text>
          <View style={styles.changeRow}>
            <View style={[styles.changeBadge, { backgroundColor: isPositive ? Colors.dark.positiveDim : Colors.dark.negativeDim }]}>
              <Ionicons
                name={isPositive ? "arrow-up" : "arrow-down"}
                size={14}
                color={isPositive ? Colors.dark.positive : Colors.dark.negative}
              />
              <Text style={[styles.changeText, { color: isPositive ? Colors.dark.positive : Colors.dark.negative }]}>
                {formatChange(Math.abs(quote.change))} ({formatPercent(quote.changePercent)})
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.rangeRow}>
          {RANGES.map((range) => (
            <Pressable
              key={range}
              style={[styles.rangeButton, selectedRange === range && styles.rangeActive]}
              onPress={() => {
                setSelectedRange(range);
                if (Platform.OS !== "web") {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                }
              }}
            >
              <Text style={[styles.rangeText, selectedRange === range && styles.rangeTextActive]}>
                {range.toUpperCase()}
              </Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.chartContainer}>
          {historyLoading ? (
            <View style={styles.chartLoading}>
              <ActivityIndicator color={Colors.dark.accent} />
            </View>
          ) : history?.prices ? (
            <StockChart data={history.prices} />
          ) : null}
        </View>

        {history?.indicators && (
          <View style={styles.indicatorsSection}>
            <Text style={styles.sectionTitle}>Technical Indicators</Text>
            <View style={styles.indicatorGrid}>
              <View style={styles.indicatorCard}>
                <Text style={styles.indicatorLabel}>SMA 20</Text>
                <Text style={styles.indicatorValue}>${formatPrice(history.indicators.sma20)}</Text>
              </View>
              <View style={styles.indicatorCard}>
                <Text style={styles.indicatorLabel}>EMA 12</Text>
                <Text style={styles.indicatorValue}>${formatPrice(history.indicators.ema12)}</Text>
              </View>
              <View style={styles.indicatorCard}>
                <Text style={styles.indicatorLabel}>RSI</Text>
                <Text style={[styles.indicatorValue, {
                  color: history.indicators.rsi > 70 ? Colors.dark.negative : history.indicators.rsi < 30 ? Colors.dark.positive : Colors.dark.text
                }]}>
                  {history.indicators.rsi.toFixed(1)}
                </Text>
              </View>
              <View style={styles.indicatorCard}>
                <Text style={styles.indicatorLabel}>MACD</Text>
                <Text style={[styles.indicatorValue, {
                  color: history.indicators.macd.value >= 0 ? Colors.dark.positive : Colors.dark.negative
                }]}>
                  {history.indicators.macd.value.toFixed(2)}
                </Text>
              </View>
            </View>
          </View>
        )}

        <View style={styles.detailsSection}>
          <Text style={styles.sectionTitle}>Details</Text>
          <View style={styles.detailGrid}>
            <DetailRow label="Open" value={`$${formatPrice(quote.open)}`} />
            <DetailRow label="Previous Close" value={`$${formatPrice(quote.previousClose)}`} />
            <DetailRow label="Day High" value={`$${formatPrice(quote.dayHigh)}`} />
            <DetailRow label="Day Low" value={`$${formatPrice(quote.dayLow)}`} />
            <DetailRow label="Volume" value={formatVolume(quote.volume)} />
            <DetailRow label="Market Cap" value={formatMarketCap(quote.marketCap)} />
            <DetailRow label="52W High" value={`$${formatPrice(quote.fiftyTwoWeekHigh)}`} />
            <DetailRow label="52W Low" value={`$${formatPrice(quote.fiftyTwoWeekLow)}`} />
          </View>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      <View style={[styles.bottomBar, { paddingBottom: Platform.OS === "web" ? 34 : 20 }]}>
        <Pressable
          style={({ pressed }) => [styles.portfolioButton, pressed && { opacity: 0.8 }]}
          onPress={() => setShowAddModal(true)}
        >
          <Ionicons name={isInPortfolio ? "checkmark-circle" : "add-circle"} size={20} color="#fff" />
          <Text style={styles.portfolioButtonText}>
            {isInPortfolio ? "Add More Shares" : "Add to Portfolio"}
          </Text>
        </Pressable>
      </View>

      <Modal visible={showAddModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add {symbol}</Text>
              <Pressable onPress={() => setShowAddModal(false)}>
                <Ionicons name="close" size={24} color={Colors.dark.text} />
              </Pressable>
            </View>
            <View style={styles.modalBody}>
              <Text style={styles.modalPrice}>Current Price: ${formatPrice(quote.price)}</Text>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Number of Shares</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="e.g. 10"
                  placeholderTextColor={Colors.dark.textMuted}
                  value={addShares}
                  onChangeText={setAddShares}
                  keyboardType="decimal-pad"
                />
              </View>
              {addShares ? (
                <Text style={styles.totalCost}>
                  Total Cost: ${formatPrice(parseFloat(addShares || "0") * quote.price)}
                </Text>
              ) : null}
              <Pressable
                style={({ pressed }) => [
                  styles.submitButton,
                  pressed && { opacity: 0.85 },
                  (!addShares || addLoading) && { opacity: 0.5 },
                ]}
                onPress={handleAddToPortfolio}
                disabled={!addShares || addLoading}
              >
                {addLoading ? (
                  <ActivityIndicator color="#fff" size="small" />
                ) : (
                  <Text style={styles.submitText}>Confirm</Text>
                )}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.detailRow}>
      <Text style={styles.detailLabel}>{label}</Text>
      <Text style={styles.detailValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: Colors.dark.background,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  errorText: {
    color: Colors.dark.textSecondary,
    fontSize: 16,
    fontFamily: "Inter_400Regular",
  },
  scrollContent: {
    paddingTop: 16,
  },
  priceSection: {
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  symbolText: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.textSecondary,
  },
  priceText: {
    fontSize: 36,
    fontFamily: "Inter_700Bold",
    color: Colors.dark.text,
    marginTop: 2,
  },
  changeRow: {
    flexDirection: "row",
    marginTop: 8,
  },
  changeBadge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    gap: 4,
  },
  changeText: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
  rangeRow: {
    flexDirection: "row",
    paddingHorizontal: 20,
    gap: 6,
    marginBottom: 16,
  },
  rangeButton: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 10,
    alignItems: "center",
    backgroundColor: Colors.dark.card,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  rangeActive: {
    backgroundColor: Colors.dark.accentDim,
    borderColor: Colors.dark.accent,
  },
  rangeText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.textMuted,
  },
  rangeTextActive: {
    color: Colors.dark.accent,
  },
  chartContainer: {
    paddingHorizontal: 4,
    marginBottom: 20,
  },
  chartLoading: {
    height: 220,
    alignItems: "center",
    justifyContent: "center",
  },
  indicatorsSection: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.text,
    marginBottom: 12,
  },
  indicatorGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  indicatorCard: {
    backgroundColor: Colors.dark.card,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    flexBasis: "48%",
    flexGrow: 1,
  },
  indicatorLabel: {
    fontSize: 12,
    fontFamily: "Inter_500Medium",
    color: Colors.dark.textSecondary,
    marginBottom: 4,
  },
  indicatorValue: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
    color: Colors.dark.text,
  },
  detailsSection: {
    paddingHorizontal: 20,
  },
  detailGrid: {
    backgroundColor: Colors.dark.card,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    overflow: "hidden",
  },
  detailRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.dark.border,
  },
  detailLabel: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textSecondary,
  },
  detailValue: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.text,
  },
  bottomBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    paddingTop: 12,
    backgroundColor: Colors.dark.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.dark.border,
  },
  portfolioButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.dark.accent,
    borderRadius: 14,
    height: 52,
    gap: 8,
  },
  portfolioButtonText: {
    color: "#fff",
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    justifyContent: "flex-end",
  },
  modalContainer: {
    backgroundColor: Colors.dark.surface,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: Colors.dark.border,
  },
  modalTitle: {
    fontSize: 20,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.text,
  },
  modalBody: {
    padding: 20,
    gap: 16,
  },
  modalPrice: {
    fontSize: 15,
    fontFamily: "Inter_500Medium",
    color: Colors.dark.textSecondary,
  },
  inputGroup: {
    gap: 6,
  },
  inputLabel: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    color: Colors.dark.textSecondary,
  },
  modalInput: {
    backgroundColor: Colors.dark.inputBg,
    borderRadius: 12,
    paddingHorizontal: 16,
    height: 48,
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  totalCost: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.accent,
  },
  submitButton: {
    backgroundColor: Colors.dark.accent,
    borderRadius: 14,
    height: 52,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
  },
  submitText: {
    color: "#fff",
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
});
