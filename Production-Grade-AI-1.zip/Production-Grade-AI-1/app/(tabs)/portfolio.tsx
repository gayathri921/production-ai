import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  TextInput,
  Modal,
  Alert,
  ActivityIndicator,
  Platform,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useQuery } from "@tanstack/react-query";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { usePortfolio } from "@/lib/portfolio-context";
import { formatPrice, formatPercent, formatMarketCap } from "@/lib/format";
import { getApiUrl } from "@/lib/query-client";
import { fetch } from "expo/fetch";
import { router } from "expo-router";

export default function PortfolioScreen() {
  const insets = useSafeAreaInsets();
  const { holdings, addHolding, removeHolding } = usePortfolio();
  const [showAddModal, setShowAddModal] = useState(false);
  const [addSymbol, setAddSymbol] = useState("");
  const [addShares, setAddShares] = useState("");
  const [addPrice, setAddPrice] = useState("");
  const [addLoading, setAddLoading] = useState(false);
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const { data: liveQuotes } = useQuery<Record<string, any>>({
    queryKey: ["/api/portfolio-quotes", holdings.map((h) => h.symbol).join(",")],
    queryFn: async () => {
      if (holdings.length === 0) return {};
      const baseUrl = getApiUrl();
      const results: Record<string, any> = {};
      await Promise.all(
        holdings.map(async (h) => {
          try {
            const url = new URL(`/api/stock/${h.symbol}`, baseUrl);
            const res = await fetch(url.toString());
            if (res.ok) {
              results[h.symbol] = await res.json();
            }
          } catch {}
        })
      );
      return results;
    },
    enabled: holdings.length > 0,
    staleTime: 30000,
    refetchInterval: 60000,
  });

  const totalValue = holdings.reduce((sum, h) => {
    const currentPrice = liveQuotes?.[h.symbol]?.price || h.avgPrice;
    return sum + currentPrice * h.shares;
  }, 0);

  const totalCost = holdings.reduce((sum, h) => sum + h.avgPrice * h.shares, 0);
  const totalPL = totalValue - totalCost;
  const totalPLPercent = totalCost > 0 ? (totalPL / totalCost) * 100 : 0;

  const [addError, setAddError] = useState("");

  const handleAdd = useCallback(async () => {
    if (!addSymbol || !addShares || !addPrice) return;
    setAddLoading(true);
    setAddError("");
    try {
      const baseUrl = getApiUrl();
      const url = new URL(`/api/stock/${addSymbol.toUpperCase()}`, baseUrl);
      const res = await fetch(url.toString());
      if (!res.ok) {
        setAddError(`"${addSymbol.toUpperCase()}" is not a valid stock symbol. Please check and try again.`);
        setAddLoading(false);
        return;
      }
      const data = await res.json();
      if (!data.price || data.price === 0) {
        setAddError(`Could not find live data for "${addSymbol.toUpperCase()}". Please verify the symbol.`);
        setAddLoading(false);
        return;
      }
      await addHolding({
        symbol: data.symbol || addSymbol.toUpperCase(),
        name: data.name || addSymbol.toUpperCase(),
        shares: parseFloat(addShares),
        avgPrice: parseFloat(addPrice),
      });
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      setShowAddModal(false);
      setAddSymbol("");
      setAddShares("");
      setAddPrice("");
      setAddError("");
    } catch (e) {
      setAddError("Could not verify stock. Please check your connection and try again.");
    } finally {
      setAddLoading(false);
    }
  }, [addSymbol, addShares, addPrice, addHolding]);

  const handleRemove = useCallback(
    (symbol: string) => {
      Alert.alert("Remove Stock", `Remove ${symbol} from portfolio?`, [
        { text: "Cancel", style: "cancel" },
        {
          text: "Remove",
          style: "destructive",
          onPress: () => {
            removeHolding(symbol);
            if (Platform.OS !== "web") {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            }
          },
        },
      ]);
    },
    [removeHolding]
  );

  const renderHolding = useCallback(
    ({ item }: { item: any }) => {
      const currentPrice = liveQuotes?.[item.symbol]?.price || item.avgPrice;
      const marketValue = currentPrice * item.shares;
      const pl = (currentPrice - item.avgPrice) * item.shares;
      const plPercent = ((currentPrice - item.avgPrice) / item.avgPrice) * 100;
      const isPositive = pl >= 0;

      return (
        <Pressable
          style={({ pressed }) => [styles.holdingCard, pressed && styles.holdingPressed]}
          onPress={() => router.push({ pathname: "/stock/[symbol]", params: { symbol: item.symbol } })}
          onLongPress={() => handleRemove(item.symbol)}
        >
          <View style={styles.holdingTop}>
            <View style={styles.holdingLeft}>
              <View style={[styles.holdingIcon, { backgroundColor: isPositive ? Colors.dark.positiveDim : Colors.dark.negativeDim }]}>
                <Ionicons name={isPositive ? "trending-up" : "trending-down"} size={16} color={isPositive ? Colors.dark.positive : Colors.dark.negative} />
              </View>
              <View>
                <Text style={styles.holdingSymbol}>{item.symbol}</Text>
                <Text style={styles.holdingName} numberOfLines={1}>{item.name}</Text>
              </View>
            </View>
            <View style={styles.holdingRight}>
              <Text style={styles.holdingValue}>${formatPrice(marketValue)}</Text>
              <Text style={[styles.holdingPL, { color: isPositive ? Colors.dark.positive : Colors.dark.negative }]}>
                {isPositive ? "+" : ""}${formatPrice(Math.abs(pl))} ({formatPercent(plPercent)})
              </Text>
            </View>
          </View>
          <View style={styles.holdingBottom}>
            <Text style={styles.holdingDetail}>{item.shares} shares @ ${formatPrice(item.avgPrice)}</Text>
            <Text style={styles.holdingDetail}>Current: ${formatPrice(currentPrice)}</Text>
          </View>
        </Pressable>
      );
    },
    [liveQuotes, handleRemove]
  );

  return (
    <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Portfolio</Text>
          <Text style={styles.subtitle}>Your holdings</Text>
        </View>
        <Pressable
          style={({ pressed }) => [styles.addButton, pressed && { opacity: 0.7 }]}
          onPress={() => setShowAddModal(true)}
        >
          <Ionicons name="add" size={24} color={Colors.dark.accent} />
        </Pressable>
      </View>

      <View style={styles.summaryCard}>
        <Text style={styles.summaryLabel}>Total Value</Text>
        <Text style={styles.summaryValue}>${formatPrice(totalValue)}</Text>
        <View style={styles.summaryRow}>
          <View style={[styles.plBadge, { backgroundColor: totalPL >= 0 ? Colors.dark.positiveDim : Colors.dark.negativeDim }]}>
            <Ionicons
              name={totalPL >= 0 ? "arrow-up" : "arrow-down"}
              size={14}
              color={totalPL >= 0 ? Colors.dark.positive : Colors.dark.negative}
            />
            <Text style={[styles.plText, { color: totalPL >= 0 ? Colors.dark.positive : Colors.dark.negative }]}>
              ${formatPrice(Math.abs(totalPL))} ({formatPercent(totalPLPercent)})
            </Text>
          </View>
        </View>
      </View>

      {holdings.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="briefcase-outline" size={56} color={Colors.dark.textMuted} />
          <Text style={styles.emptyTitle}>No holdings yet</Text>
          <Text style={styles.emptySubtext}>Add stocks to track your portfolio</Text>
          <Pressable
            style={({ pressed }) => [styles.emptyButton, pressed && { opacity: 0.8 }]}
            onPress={() => setShowAddModal(true)}
          >
            <Ionicons name="add" size={18} color="#fff" />
            <Text style={styles.emptyButtonText}>Add Stock</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={holdings}
          renderItem={renderHolding}
          keyExtractor={(item) => item.symbol}
          contentContainerStyle={[styles.list, { paddingBottom: 100 }]}
          showsVerticalScrollIndicator={false}
          scrollEnabled={holdings.length > 0}
        />
      )}

      <Modal visible={showAddModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Stock</Text>
              <Pressable onPress={() => { setShowAddModal(false); setAddError(""); }}>
                <Ionicons name="close" size={24} color={Colors.dark.text} />
              </Pressable>
            </View>
            <View style={styles.modalBody}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Symbol</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="e.g. AAPL"
                  placeholderTextColor={Colors.dark.textMuted}
                  value={addSymbol}
                  onChangeText={(text) => { setAddSymbol(text); setAddError(""); }}
                  autoCapitalize="characters"
                  autoCorrect={false}
                />
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Number of Shares</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="e.g. 10"
                  placeholderTextColor={Colors.dark.textMuted}
                  value={addShares}
                  onChangeText={setAddShares}
                  keyboardType="decimal-pad"
                />
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Average Price ($)</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="e.g. 150.00"
                  placeholderTextColor={Colors.dark.textMuted}
                  value={addPrice}
                  onChangeText={setAddPrice}
                  keyboardType="decimal-pad"
                />
              </View>
              {addError ? (
                <View style={styles.addErrorCard}>
                  <Ionicons name="alert-circle" size={16} color={Colors.dark.negative} />
                  <Text style={styles.addErrorText}>{addError}</Text>
                </View>
              ) : null}
              <Pressable
                style={({ pressed }) => [
                  styles.submitButton,
                  pressed && { opacity: 0.85 },
                  (!addSymbol || !addShares || !addPrice) && styles.submitDisabled,
                ]}
                onPress={handleAdd}
                disabled={!addSymbol || !addShares || !addPrice || addLoading}
              >
                {addLoading ? (
                  <ActivityIndicator color="#fff" size="small" />
                ) : (
                  <Text style={styles.submitText}>Add to Portfolio</Text>
                )}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  title: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    color: Colors.dark.text,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textSecondary,
    marginTop: 2,
  },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: Colors.dark.accentDim,
    alignItems: "center",
    justifyContent: "center",
  },
  summaryCard: {
    marginHorizontal: 20,
    backgroundColor: Colors.dark.card,
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  summaryLabel: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    color: Colors.dark.textSecondary,
  },
  summaryValue: {
    fontSize: 32,
    fontFamily: "Inter_700Bold",
    color: Colors.dark.text,
    marginTop: 4,
  },
  summaryRow: {
    flexDirection: "row",
    marginTop: 8,
  },
  plBadge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    gap: 4,
  },
  plText: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
  list: {
    paddingHorizontal: 20,
  },
  holdingCard: {
    backgroundColor: Colors.dark.card,
    borderRadius: 16,
    padding: 16,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  holdingPressed: {
    opacity: 0.85,
  },
  holdingTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  holdingLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  holdingIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10,
  },
  holdingSymbol: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.text,
  },
  holdingName: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textSecondary,
    maxWidth: 120,
  },
  holdingRight: {
    alignItems: "flex-end",
  },
  holdingValue: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.text,
  },
  holdingPL: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
    marginTop: 2,
  },
  holdingBottom: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: Colors.dark.border,
  },
  holdingDetail: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textMuted,
  },
  emptyState: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 100,
    gap: 8,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.textSecondary,
    marginTop: 8,
  },
  emptySubtext: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textMuted,
  },
  emptyButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.dark.accent,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 14,
    marginTop: 12,
    gap: 6,
  },
  emptyButtonText: {
    color: "#fff",
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    justifyContent: "flex-end",
  },
  modalContainer: {
    backgroundColor: Colors.dark.surface,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: Colors.dark.border,
  },
  modalTitle: {
    fontSize: 20,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.text,
  },
  modalBody: {
    padding: 20,
    gap: 16,
  },
  inputGroup: {
    gap: 6,
  },
  inputLabel: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    color: Colors.dark.textSecondary,
  },
  modalInput: {
    backgroundColor: Colors.dark.inputBg,
    borderRadius: 12,
    paddingHorizontal: 16,
    height: 48,
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  submitButton: {
    backgroundColor: Colors.dark.accent,
    borderRadius: 14,
    height: 52,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 8,
  },
  submitDisabled: {
    opacity: 0.5,
  },
  submitText: {
    color: "#fff",
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  addErrorCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.dark.negativeDim,
    borderRadius: 12,
    padding: 12,
    gap: 8,
  },
  addErrorText: {
    color: Colors.dark.negative,
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    flex: 1,
    lineHeight: 18,
  },
});
