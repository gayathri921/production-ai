import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  Pressable,
  ActivityIndicator,
  Platform,
  RefreshControl,
} from "react-native";
import { useQuery } from "@tanstack/react-query";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { StockCard } from "@/components/StockCard";
import { getApiUrl } from "@/lib/query-client";
import { fetch } from "expo/fetch";

export default function MarketsScreen() {
  const insets = useSafeAreaInsets();
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const {
    data: trending,
    isLoading,
    refetch,
    isRefetching,
  } = useQuery<any[]>({
    queryKey: ["/api/trending"],
    staleTime: 60000,
    refetchInterval: 60000,
  });

  const handleSearch = useCallback(async (query: string) => {
    setSearchQuery(query);
    if (query.length < 1) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }
    setIsSearching(true);
    setSearchLoading(true);
    try {
      const baseUrl = getApiUrl();
      const url = new URL(`/api/stock/${encodeURIComponent(query)}/search`, baseUrl);
      const res = await fetch(url.toString());
      if (res.ok) {
        const data = await res.json();
        setSearchResults(data);
      }
    } catch (e) {
      console.error("Search error:", e);
    } finally {
      setSearchLoading(false);
    }
  }, []);

  const openStock = useCallback((symbol: string) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push({ pathname: "/stock/[symbol]", params: { symbol } });
  }, []);

  const renderTrendingItem = useCallback(
    ({ item }: { item: any }) => (
      <StockCard
        symbol={item.symbol}
        name={item.name}
        price={item.price}
        change={item.change}
        changePercent={item.changePercent}
        onPress={() => openStock(item.symbol)}
      />
    ),
    [openStock]
  );

  const renderSearchItem = useCallback(
    ({ item }: { item: any }) => (
      <Pressable
        style={({ pressed }) => [styles.searchItem, pressed && styles.searchItemPressed]}
        onPress={() => {
          openStock(item.symbol);
          setSearchQuery("");
          setIsSearching(false);
          setSearchResults([]);
        }}
      >
        <View style={styles.searchIcon}>
          <Ionicons name="stats-chart" size={18} color={Colors.dark.accent} />
        </View>
        <View style={styles.searchInfo}>
          <Text style={styles.searchSymbol}>{item.symbol}</Text>
          <Text style={styles.searchName} numberOfLines={1}>{item.name}</Text>
        </View>
        <Ionicons name="chevron-forward" size={18} color={Colors.dark.textMuted} />
      </Pressable>
    ),
    [openStock]
  );

  return (
    <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Markets</Text>
        <Text style={styles.subtitle}>Real-time stock data</Text>
      </View>

      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={Colors.dark.textMuted} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search stocks..."
          placeholderTextColor={Colors.dark.textMuted}
          value={searchQuery}
          onChangeText={handleSearch}
          autoCapitalize="characters"
          autoCorrect={false}
        />
        {searchQuery.length > 0 && (
          <Pressable
            onPress={() => {
              setSearchQuery("");
              setIsSearching(false);
              setSearchResults([]);
            }}
          >
            <Ionicons name="close-circle" size={18} color={Colors.dark.textMuted} />
          </Pressable>
        )}
      </View>

      {isSearching ? (
        <View style={styles.listContainer}>
          {searchLoading ? (
            <ActivityIndicator color={Colors.dark.accent} style={styles.loader} />
          ) : searchResults.length === 0 ? (
            <View style={styles.emptyState}>
              <Ionicons name="search-outline" size={48} color={Colors.dark.textMuted} />
              <Text style={styles.emptyText}>No results found</Text>
            </View>
          ) : (
            <FlatList
              data={searchResults}
              renderItem={renderSearchItem}
              keyExtractor={(item) => item.symbol}
              contentContainerStyle={styles.list}
              showsVerticalScrollIndicator={false}
            />
          )}
        </View>
      ) : (
        <View style={styles.listContainer}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionDot} />
            <Text style={styles.sectionTitle}>Trending</Text>
          </View>
          {isLoading ? (
            <View style={styles.loadingContainer}>
              {[1, 2, 3, 4].map((i) => (
                <View key={i} style={styles.skeleton} />
              ))}
            </View>
          ) : (
            <FlatList
              data={trending || []}
              renderItem={renderTrendingItem}
              keyExtractor={(item) => item.symbol}
              contentContainerStyle={[styles.list, { paddingBottom: 100 }]}
              showsVerticalScrollIndicator={false}
              scrollEnabled={!!(trending && trending.length > 0)}
              refreshControl={
                <RefreshControl
                  refreshing={isRefetching}
                  onRefresh={refetch}
                  tintColor={Colors.dark.accent}
                />
              }
            />
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 8,
  },
  title: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    color: Colors.dark.text,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textSecondary,
    marginTop: 2,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.dark.inputBg,
    marginHorizontal: 20,
    marginVertical: 12,
    borderRadius: 14,
    paddingHorizontal: 14,
    height: 46,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  searchInput: {
    flex: 1,
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    marginLeft: 10,
    height: "100%",
  },
  listContainer: {
    flex: 1,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  sectionDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.dark.accent,
    marginRight: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.textSecondary,
  },
  list: {
    paddingHorizontal: 20,
  },
  searchItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.dark.card,
    borderRadius: 14,
    padding: 14,
    marginBottom: 8,
    marginHorizontal: 20,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  searchItemPressed: {
    opacity: 0.8,
  },
  searchIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: Colors.dark.accentDim,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  searchInfo: {
    flex: 1,
  },
  searchSymbol: {
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
  },
  searchName: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  loader: {
    marginTop: 40,
  },
  emptyState: {
    alignItems: "center",
    paddingTop: 60,
    gap: 12,
  },
  emptyText: {
    color: Colors.dark.textMuted,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  loadingContainer: {
    paddingHorizontal: 20,
    gap: 8,
  },
  skeleton: {
    height: 72,
    backgroundColor: Colors.dark.shimmer,
    borderRadius: 16,
  },
});
