import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Pressable,
  ScrollView,
  ActivityIndicator,
  Platform,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";
import { formatPrice, formatPercent } from "@/lib/format";
import { getApiUrl } from "@/lib/query-client";
import { fetch } from "expo/fetch";

interface Prediction {
  symbol: string;
  currentPrice: number;
  predictedPrice: number;
  priceChange: number;
  percentChange: number;
  trend: string;
  signal: string;
  confidence: number;
  rsi: number;
  sma20: number | null;
  disclaimer: string;
}

export default function PredictScreen() {
  const insets = useSafeAreaInsets();
  const [symbol, setSymbol] = useState("");
  const [loading, setLoading] = useState(false);
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [error, setError] = useState("");
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const fetchPrediction = useCallback(async () => {
    if (!symbol.trim()) return;
    setLoading(true);
    setError("");
    setPrediction(null);
    try {
      const baseUrl = getApiUrl();
      const url = new URL(`/api/predict/${symbol.toUpperCase()}`, baseUrl);
      const res = await fetch(url.toString());
      if (!res.ok) {
        throw new Error("Prediction failed");
      }
      const data = await res.json();
      setPrediction(data);
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (e: any) {
      setError("Could not generate prediction. Please check the symbol.");
    } finally {
      setLoading(false);
    }
  }, [symbol]);

  const getSignalColor = (signal: string) => {
    if (signal.includes("Buy")) return Colors.dark.positive;
    if (signal.includes("Sell")) return Colors.dark.negative;
    return Colors.dark.warning;
  };

  const getSignalBg = (signal: string) => {
    if (signal.includes("Buy")) return Colors.dark.positiveDim;
    if (signal.includes("Sell")) return Colors.dark.negativeDim;
    return Colors.dark.warningDim;
  };

  const getTrendIcon = (trend: string): any => {
    if (trend === "Bullish") return "trending-up";
    if (trend === "Bearish") return "trending-down";
    return "remove";
  };

  return (
    <ScrollView
      style={[styles.container, { paddingTop: insets.top + webTopInset }]}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <Text style={styles.title}>AI Predict</Text>
        <Text style={styles.subtitle}>ML-powered stock analysis</Text>
      </View>

      <View style={styles.inputRow}>
        <View style={styles.inputWrapper}>
          <Ionicons name="search" size={18} color={Colors.dark.textMuted} />
          <TextInput
            style={styles.input}
            placeholder="Enter symbol (e.g. AAPL)"
            placeholderTextColor={Colors.dark.textMuted}
            value={symbol}
            onChangeText={setSymbol}
            autoCapitalize="characters"
            autoCorrect={false}
            onSubmitEditing={fetchPrediction}
          />
        </View>
        <Pressable
          style={({ pressed }) => [styles.analyzeButton, pressed && { opacity: 0.8 }, loading && { opacity: 0.6 }]}
          onPress={fetchPrediction}
          disabled={loading || !symbol.trim()}
        >
          {loading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Ionicons name="sparkles" size={20} color="#fff" />
          )}
        </Pressable>
      </View>

      {error ? (
        <View style={styles.errorCard}>
          <Ionicons name="alert-circle" size={20} color={Colors.dark.negative} />
          <Text style={styles.errorText}>{error}</Text>
        </View>
      ) : null}

      {loading && !prediction ? (
        <View style={styles.loadingState}>
          <ActivityIndicator color={Colors.dark.accent} size="large" />
          <Text style={styles.loadingText}>Analyzing {symbol.toUpperCase()}...</Text>
          <Text style={styles.loadingSubtext}>Running regression model</Text>
        </View>
      ) : null}

      {prediction ? (
        <View style={styles.results}>
          <View style={styles.signalCard}>
            <View style={[styles.signalBadge, { backgroundColor: getSignalBg(prediction.signal) }]}>
              <Ionicons name={getTrendIcon(prediction.trend)} size={28} color={getSignalColor(prediction.signal)} />
            </View>
            <Text style={[styles.signalText, { color: getSignalColor(prediction.signal) }]}>
              {prediction.signal}
            </Text>
            <Text style={styles.trendText}>{prediction.trend} Trend</Text>
          </View>

          <View style={styles.priceRow}>
            <View style={styles.priceCard}>
              <Text style={styles.priceLabel}>Current</Text>
              <Text style={styles.priceValue}>${formatPrice(prediction.currentPrice)}</Text>
            </View>
            <View style={styles.arrowContainer}>
              <Ionicons name="arrow-forward" size={20} color={Colors.dark.textMuted} />
            </View>
            <View style={styles.priceCard}>
              <Text style={styles.priceLabel}>Predicted</Text>
              <Text style={[styles.priceValue, { color: prediction.priceChange >= 0 ? Colors.dark.positive : Colors.dark.negative }]}>
                ${formatPrice(prediction.predictedPrice)}
              </Text>
            </View>
          </View>

          <View style={styles.metricsGrid}>
            <View style={styles.metricCard}>
              <Ionicons name="analytics" size={18} color={Colors.dark.accent} />
              <Text style={styles.metricLabel}>Confidence</Text>
              <Text style={styles.metricValue}>{prediction.confidence}%</Text>
              <View style={styles.confidenceBar}>
                <View style={[styles.confidenceFill, { width: `${prediction.confidence}%` }]} />
              </View>
            </View>
            <View style={styles.metricCard}>
              <Ionicons name="pulse" size={18} color={Colors.dark.accent} />
              <Text style={styles.metricLabel}>RSI</Text>
              <Text style={[styles.metricValue, {
                color: prediction.rsi > 70 ? Colors.dark.negative : prediction.rsi < 30 ? Colors.dark.positive : Colors.dark.text
              }]}>{prediction.rsi.toFixed(1)}</Text>
              <Text style={styles.metricSubtext}>
                {prediction.rsi > 70 ? "Overbought" : prediction.rsi < 30 ? "Oversold" : "Neutral"}
              </Text>
            </View>
            <View style={styles.metricCard}>
              <Ionicons name="swap-vertical" size={18} color={Colors.dark.accent} />
              <Text style={styles.metricLabel}>Expected</Text>
              <Text style={[styles.metricValue, { color: prediction.percentChange >= 0 ? Colors.dark.positive : Colors.dark.negative }]}>
                {formatPercent(prediction.percentChange)}
              </Text>
            </View>
            {prediction.sma20 != null && (
              <View style={styles.metricCard}>
                <Ionicons name="bar-chart" size={18} color={Colors.dark.accent} />
                <Text style={styles.metricLabel}>SMA 20</Text>
                <Text style={styles.metricValue}>${formatPrice(prediction.sma20)}</Text>
              </View>
            )}
          </View>

          <View style={styles.disclaimerCard}>
            <Ionicons name="information-circle" size={16} color={Colors.dark.warning} />
            <Text style={styles.disclaimerText}>{prediction.disclaimer}</Text>
          </View>
        </View>
      ) : !loading && !error ? (
        <View style={styles.emptyState}>
          <View style={styles.emptyIcon}>
            <Ionicons name="sparkles" size={40} color={Colors.dark.accent} />
          </View>
          <Text style={styles.emptyTitle}>AI Stock Analysis</Text>
          <Text style={styles.emptySubtext}>
            Enter a stock symbol to get ML-powered predictions with trend analysis and buy/sell signals
          </Text>
        </View>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.background,
  },
  content: {
    paddingBottom: 120,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  title: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    color: Colors.dark.text,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textSecondary,
    marginTop: 2,
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    gap: 10,
    marginBottom: 20,
  },
  inputWrapper: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.dark.inputBg,
    borderRadius: 14,
    paddingHorizontal: 14,
    height: 48,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  input: {
    flex: 1,
    color: Colors.dark.text,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    marginLeft: 10,
    height: "100%",
  },
  analyzeButton: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: Colors.dark.accent,
    alignItems: "center",
    justifyContent: "center",
  },
  errorCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.dark.negativeDim,
    marginHorizontal: 20,
    borderRadius: 12,
    padding: 14,
    gap: 8,
    marginBottom: 16,
  },
  errorText: {
    color: Colors.dark.negative,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    flex: 1,
  },
  loadingState: {
    alignItems: "center",
    paddingTop: 60,
    gap: 12,
  },
  loadingText: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.text,
  },
  loadingSubtext: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textMuted,
  },
  results: {
    paddingHorizontal: 20,
    gap: 12,
  },
  signalCard: {
    backgroundColor: Colors.dark.card,
    borderRadius: 20,
    padding: 24,
    alignItems: "center",
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  signalBadge: {
    width: 60,
    height: 60,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  signalText: {
    fontSize: 24,
    fontFamily: "Inter_700Bold",
  },
  trendText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textSecondary,
    marginTop: 4,
  },
  priceRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  priceCard: {
    flex: 1,
    backgroundColor: Colors.dark.card,
    borderRadius: 16,
    padding: 16,
    alignItems: "center",
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  arrowContainer: {
    width: 32,
    alignItems: "center",
  },
  priceLabel: {
    fontSize: 12,
    fontFamily: "Inter_500Medium",
    color: Colors.dark.textSecondary,
    marginBottom: 4,
  },
  priceValue: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
    color: Colors.dark.text,
  },
  metricsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  metricCard: {
    backgroundColor: Colors.dark.card,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    flexBasis: "48%",
    flexGrow: 1,
    gap: 4,
  },
  metricLabel: {
    fontSize: 12,
    fontFamily: "Inter_500Medium",
    color: Colors.dark.textSecondary,
  },
  metricValue: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    color: Colors.dark.text,
  },
  metricSubtext: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textMuted,
  },
  confidenceBar: {
    height: 4,
    backgroundColor: Colors.dark.border,
    borderRadius: 2,
    marginTop: 4,
  },
  confidenceFill: {
    height: 4,
    backgroundColor: Colors.dark.accent,
    borderRadius: 2,
  },
  disclaimerCard: {
    flexDirection: "row",
    backgroundColor: Colors.dark.warningDim,
    borderRadius: 12,
    padding: 14,
    gap: 8,
    alignItems: "flex-start",
  },
  disclaimerText: {
    color: Colors.dark.warning,
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    flex: 1,
    lineHeight: 18,
  },
  emptyState: {
    alignItems: "center",
    paddingTop: 80,
    paddingHorizontal: 40,
    gap: 8,
  },
  emptyIcon: {
    width: 72,
    height: 72,
    borderRadius: 24,
    backgroundColor: Colors.dark.accentDim,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: "Inter_600SemiBold",
    color: Colors.dark.text,
  },
  emptySubtext: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    color: Colors.dark.textMuted,
    textAlign: "center",
    lineHeight: 20,
  },
});
