import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export interface PortfolioItem {
  symbol: string;
  name: string;
  shares: number;
  avgPrice: number;
  addedAt: string;
}

interface PortfolioContextValue {
  holdings: PortfolioItem[];
  addHolding: (item: Omit<PortfolioItem, "addedAt">) => Promise<void>;
  removeHolding: (symbol: string) => Promise<void>;
  isLoading: boolean;
}

const PortfolioContext = createContext<PortfolioContextValue | null>(null);

const STORAGE_KEY = "@stockai_portfolio";

export function PortfolioProvider({ children }: { children: ReactNode }) {
  const [holdings, setHoldings] = useState<PortfolioItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPortfolio();
  }, []);

  const loadPortfolio = async () => {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEY);
      if (data) {
        setHoldings(JSON.parse(data));
      }
    } catch (e) {
      console.error("Failed to load portfolio:", e);
    } finally {
      setIsLoading(false);
    }
  };

  const savePortfolio = async (items: PortfolioItem[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch (e) {
      console.error("Failed to save portfolio:", e);
    }
  };

  const addHolding = useCallback(async (item: Omit<PortfolioItem, "addedAt">) => {
    setHoldings((prev) => {
      const existing = prev.find((h) => h.symbol === item.symbol);
      let updated: PortfolioItem[];
      if (existing) {
        const totalShares = existing.shares + item.shares;
        const totalCost = existing.shares * existing.avgPrice + item.shares * item.avgPrice;
        const newAvg = totalCost / totalShares;
        updated = prev.map((h) =>
          h.symbol === item.symbol ? { ...h, shares: totalShares, avgPrice: newAvg } : h
        );
      } else {
        updated = [...prev, { ...item, addedAt: new Date().toISOString() }];
      }
      savePortfolio(updated);
      return updated;
    });
  }, []);

  const removeHolding = useCallback(async (symbol: string) => {
    setHoldings((prev) => {
      const updated = prev.filter((h) => h.symbol !== symbol);
      savePortfolio(updated);
      return updated;
    });
  }, []);

  const value = useMemo(
    () => ({ holdings, addHolding, removeHolding, isLoading }),
    [holdings, addHolding, removeHolding, isLoading]
  );

  return <PortfolioContext.Provider value={value}>{children}</PortfolioContext.Provider>;
}

export function usePortfolio() {
  const context = useContext(PortfolioContext);
  if (!context) {
    throw new Error("usePortfolio must be used within PortfolioProvider");
  }
  return context;
}
