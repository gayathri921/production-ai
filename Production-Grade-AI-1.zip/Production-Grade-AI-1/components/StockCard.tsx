import React from "react";
import { View, Text, Pressable, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import Colors from "@/constants/colors";
import { formatPrice, formatChange, formatPercent } from "@/lib/format";

interface StockCardProps {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  onPress?: () => void;
}

export function StockCard({ symbol, name, price, change, changePercent, onPress }: StockCardProps) {
  const isPositive = change >= 0;
  const color = isPositive ? Colors.dark.positive : Colors.dark.negative;
  const bgColor = isPositive ? Colors.dark.positiveDim : Colors.dark.negativeDim;

  return (
    <Pressable
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
      onPress={onPress}
    >
      <View style={styles.left}>
        <View style={[styles.iconBox, { backgroundColor: bgColor }]}>
          <Ionicons
            name={isPositive ? "trending-up" : "trending-down"}
            size={18}
            color={color}
          />
        </View>
        <View style={styles.info}>
          <Text style={styles.symbol} numberOfLines={1}>{symbol}</Text>
          <Text style={styles.name} numberOfLines={1}>{name}</Text>
        </View>
      </View>
      <View style={styles.right}>
        <Text style={styles.price}>${formatPrice(price)}</Text>
        <View style={[styles.changeBadge, { backgroundColor: bgColor }]}>
          <Text style={[styles.changeText, { color }]}>
            {formatPercent(changePercent)}
          </Text>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: Colors.dark.card,
    borderRadius: 16,
    padding: 16,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  pressed: {
    opacity: 0.85,
    transform: [{ scale: 0.98 }],
  },
  left: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
    marginRight: 12,
  },
  iconBox: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  info: {
    flex: 1,
  },
  symbol: {
    color: Colors.dark.text,
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  name: {
    color: Colors.dark.textSecondary,
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  right: {
    alignItems: "flex-end",
  },
  price: {
    color: Colors.dark.text,
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  changeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    marginTop: 4,
  },
  changeText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
});
