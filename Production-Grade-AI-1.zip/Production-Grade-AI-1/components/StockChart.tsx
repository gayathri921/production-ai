import React, { useMemo } from "react";
import { View, StyleSheet, Dimensions, Text } from "react-native";
import Svg, { Path, Line, Text as SvgText } from "react-native-svg";
import Colors from "@/constants/colors";
import { formatPrice } from "@/lib/format";

interface PricePoint {
  date: string;
  close: number;
}

interface StockChartProps {
  data: PricePoint[];
  height?: number;
  showLabels?: boolean;
}

export function StockChart({ data, height = 220, showLabels = true }: StockChartProps) {
  const screenWidth = Dimensions.get("window").width;
  const width = screenWidth - 48;
  const paddingLeft = showLabels ? 50 : 8;
  const paddingRight = 8;
  const paddingTop = 12;
  const paddingBottom = showLabels ? 28 : 8;

  const chartData = useMemo(() => {
    if (!data || data.length < 2) return null;

    const closes = data.map((d) => d.close);
    const min = Math.min(...closes);
    const max = Math.max(...closes);
    const range = max - min || 1;
    const chartWidth = width - paddingLeft - paddingRight;
    const chartHeight = height - paddingTop - paddingBottom;

    const points = closes.map((val, i) => {
      const x = paddingLeft + (i / (closes.length - 1)) * chartWidth;
      const y = paddingTop + chartHeight - ((val - min) / range) * chartHeight;
      return { x, y };
    });

    const pathData = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");

    const areaPath =
      pathData +
      ` L ${points[points.length - 1].x} ${paddingTop + chartHeight}` +
      ` L ${paddingLeft} ${paddingTop + chartHeight} Z`;

    const isPositive = closes[closes.length - 1] >= closes[0];

    const gridLines = [];
    const numGridLines = 4;
    for (let i = 0; i <= numGridLines; i++) {
      const y = paddingTop + (chartHeight / numGridLines) * i;
      const value = max - (range / numGridLines) * i;
      gridLines.push({ y, value });
    }

    return { pathData, areaPath, isPositive, gridLines, chartWidth, chartHeight, closes };
  }, [data, width, height]);

  if (!chartData) {
    return (
      <View style={[styles.empty, { height }]}>
        <Text style={styles.emptyText}>No chart data available</Text>
      </View>
    );
  }

  const color = chartData.isPositive ? Colors.dark.positive : Colors.dark.negative;
  const gradientColor = chartData.isPositive
    ? "rgba(16, 185, 129, 0.08)"
    : "rgba(239, 68, 68, 0.08)";

  return (
    <View style={styles.container}>
      <Svg width={width} height={height}>
        {showLabels &&
          chartData.gridLines.map((line, i) => (
            <React.Fragment key={i}>
              <Line
                x1={paddingLeft}
                y1={line.y}
                x2={width - paddingRight}
                y2={line.y}
                stroke={Colors.dark.chartGrid}
                strokeWidth={0.5}
                strokeDasharray="4,4"
              />
              <SvgText
                x={paddingLeft - 6}
                y={line.y + 4}
                fill={Colors.dark.textMuted}
                fontSize={10}
                textAnchor="end"
                fontFamily="Inter_400Regular"
              >
                {formatPrice(line.value)}
              </SvgText>
            </React.Fragment>
          ))}
        <Path d={chartData.areaPath} fill={gradientColor} />
        <Path d={chartData.pathData} fill="none" stroke={color} strokeWidth={2} strokeLinejoin="round" />
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
  },
  empty: {
    alignItems: "center",
    justifyContent: "center",
  },
  emptyText: {
    color: Colors.dark.textMuted,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
});
